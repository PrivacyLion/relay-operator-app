#!/bin/bash
# Linux build script using pyinstaller