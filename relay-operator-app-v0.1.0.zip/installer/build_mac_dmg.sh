#!/bin/bash
# macOS build script using pyinstaller