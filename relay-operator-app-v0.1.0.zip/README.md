[![Build Status](https://github.com/PrivacyLion/relay-operator-app/actions/workflows/build.yml/badge.svg)](https://github.com/PrivacyLion/relay-operator-app/actions/workflows/build.yml)
[![License: MIT](https://img.shields.io/github/license/PrivacyLion/relay-operator-app)](LICENSE)
[![Latest Release](https://img.shields.io/github/v/release/PrivacyLion/relay-operator-app)](https://github.com/PrivacyLion/relay-operator-app/releases/latest)

# Relay Operator App

Documentation will go here.
